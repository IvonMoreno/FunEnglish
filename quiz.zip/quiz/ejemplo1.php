<?PHP

$sal=$_REQUEST['saludos'];
$sal1=$_REQUEST['saludos1'];
$sal2=$_REQUEST['saludos2'];
$sal3=$_REQUEST['saludos3'];

echo "Respuesta1: $sal <br>";
echo "Respuesta2: $sal1 <br>";
echo "Respesta3: $sal2 <br>";
echo "Respuesta4: $sal3 <br>";


?>